package de.honoka.sdk.spring.starter.security.token

import cn.hutool.cache.CacheUtil
import cn.hutool.core.bean.BeanUtil
import cn.hutool.core.date.DateField
import cn.hutool.core.date.DateTime
import cn.hutool.jwt.JWT
import de.honoka.sdk.spring.starter.config.SecurityProperties
import de.honoka.sdk.spring.starter.core.springBeanLazy
import de.honoka.sdk.spring.starter.security.DefaultUser
import org.springframework.security.core.context.SecurityContextHolder
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter
import org.springframework.security.oauth2.server.resource.authentication.JwtGrantedAuthoritiesConverter
import org.springframework.security.web.authentication.rememberme.InvalidCookieException
import java.util.concurrent.TimeUnit

object JwtUtils {

    private val securityProperties by SecurityProperties::class.springBeanLazy

    private val tokenCache = CacheUtil.newTimedCache<String, String?>(0).apply {
        /**
         * 设置间隔多长时间主动清理过期缓存，防止过期缓存长时间未读取而滞留在内存中。
         *
         * 需要注意的是，并不是过期缓存没有被主动清理就意味着缓存没有过期，每次从缓存中取值时，即使取到了
         * 值也会再次检查取到的值是否已过期，如果已过期将会立刻清理此值。
         * @see cn.hutool.cache.impl.StampedCache.get
         */
        schedulePrune(TimeUnit.HOURS.toMillis(1))
    }

    fun newJwt(user: DefaultUser, timeoutDays: Int = 7): String = JWT.create().run {
        setKey(securityProperties.jwt.key.toByteArray())
        val payload = mapOf("user" to BeanUtil.beanToMap(user))
        addPayloads(payload)
        val now = DateTime.now()
        val expireAt = now.offsetNew(DateField.DAY_OF_YEAR, timeoutDays)
        setIssuedAt(now)
        setNotBefore(now)
        setExpiresAt(expireAt)
        val timeout = expireAt.time - now.time
        tokenCache.put("${user.id}-${now.time / 1000L}", null, timeout)
        sign()
    }
    
    fun parseAvaliableJwt(token: String): JWT = JWT(token).apply {
        setKey(securityProperties.jwt.key.toByteArray())
        if(validate(0) && tokenCache.containsKey(cacheKey)) return@apply
        throw InvalidCookieException("JWT无效或已过期")
    }
    
    fun cancelJwt() {
        val jwt = SecurityContextHolder.getContext().authentication.credentials as JWT
        tokenCache.remove(jwt.cacheKey)
    }

    fun newJwtAuthenticationConverter(
        authoritiesClaimName: String = "authorities", authorityPrefix: String = ""
    ): JwtAuthenticationConverter {
        val authoritiesConverter = JwtGrantedAuthoritiesConverter().apply {
            setAuthoritiesClaimName(authoritiesClaimName)
            setAuthorityPrefix(authorityPrefix)
        }
        val authenticationConverter = JwtAuthenticationConverter().apply {
            setJwtGrantedAuthoritiesConverter(authoritiesConverter)
        }
        return authenticationConverter
    }
}

private val JWT.cacheKey: String
    get() = "${payloads.getByPath("user.id")}-${payloads["iat"]}"
