package de.honoka.sdk.util.kotlin.various

import java.net.BindException
import java.net.InetSocketAddress
import java.nio.channels.ServerSocketChannel

@Suppress("MemberVisibilityCanBePrivate")
object SocketUtils {

    fun newServerSocketChannel(firstTryPort: Int, tryCount: Int = 1): ServerSocketChannel {
        val channel = ServerSocketChannel.open()
        channel.run {
            configureBlocking(false)
            runCatching {
                tryBlock(tryCount, ignoredExceptionTypes = listOf(BindException::class)) {
                    bind(InetSocketAddress(firstTryPort + it))
                }
            }.getOrElse {
                close()
                val msg = "端口范围（$firstTryPort - ${firstTryPort + tryCount - 1}）均被占用"
                error(msg, it)
            }
        }
        return channel
    }

    fun findAvailablePort(firstTryPort: Int, tryCount: Int = 1): Int {
        newServerSocketChannel(firstTryPort, tryCount).use {
            return it.localAddress.cast<InetSocketAddress>().port
        }
    }

    fun parseHostAndPort(address: String): Pair<String, Int> {
        val parts = address.split(":")
        runCatching {
            return parts[0] to parts[1].toInt()
        }.getOrElse {
            error("Invalid address: $address")
        }
    }

    fun parseInetSocketAddress(address: String): InetSocketAddress = parseHostAndPort(address).run {
        InetSocketAddress(first, second)
    }
}